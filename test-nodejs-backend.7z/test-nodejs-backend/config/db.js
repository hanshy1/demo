const pg = require('pg')

//tcp://用户名：密码@localhost/数据库名
// const conString = "tcp://admin:1qaz!QAZ@localhost:5432/progress_dev"

const config = {
    user: 'postgres',
    password: '1qaz!QAZ',
    database: 'progress_dev',
    port: 5432,
    max: 20,
    idleTimeoutMillis: 3000
}

// const client = new pg.Client(conString);

module.exports =  function createConnnectPool() {
    return new pg.Pool(config)
}





