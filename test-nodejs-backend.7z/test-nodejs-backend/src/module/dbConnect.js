const dbConnectPool = require('../../config/db')

const db = dbConnectPool()

/**
 * 
 * @param {*} sqlString 
 * @param {*} callback 
 */
function query(sqlString, callback) {
    db.connect(function(err, client, done) {
        if (err) {
            // logger
            return console.error('db err', err)
        } else {
            client.query(sqlString, function(err, result) {
                done()
                if (err) {
                    // logger
                    return console.error('db err', err)
                }
                return callback(result)
            })
        }
    })
}



module.exports = function() {
    this.query = query
} 

